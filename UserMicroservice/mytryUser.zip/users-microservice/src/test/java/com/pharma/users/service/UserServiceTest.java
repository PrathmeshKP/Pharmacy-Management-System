package com.pharma.users.service;

import com.pharma.users.model.User;
import com.pharma.users.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    private UserRepository userRepository;
    private UserService userService;

    @BeforeEach
    void setup() {
        userRepository = mock(UserRepository.class);
        userService = new UserService();
        userService.setUserRepository(userRepository);
    }

    @Test
    void testAddUser() {
        User user = new User();
        user.setEmail("test@example.com");

        when(userRepository.save(user)).thenReturn(user);

        User result = userService.addUser(user);

        assertEquals("test@example.com", result.getEmail());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testGetAllUsers() {
        List<User> userList = Arrays.asList(new User(), new User());
        when(userRepository.findAll()).thenReturn(userList);

        List<User> result = userService.getAllUsers();

        assertEquals(2, result.size());
    }

    @Test
    void testGetUserById() {
        User user = new User();
        user.setId(123L);

        when(userRepository.findById(123L)).thenReturn(Optional.of(user));

        Optional<User> result = userService.getUserById(123L);

        assertTrue(result.isPresent());
        assertEquals(123L, result.get().getId());
    }

    @Test
    void testGetUserByEmail() {
        User user = new User();
        user.setEmail("mail@example.com");

        when(userRepository.findByEmail("mail@example.com")).thenReturn(Optional.of(user));

        Optional<User> result = userService.getUserByEmail("mail@example.com");

        assertTrue(result.isPresent());
        assertEquals("mail@example.com", result.get().getEmail());
    }

    @Test
    void testUpdateUser() {
        User updated = new User();
        updated.setName("Updated");

        when(userRepository.save(updated)).thenReturn(updated);

        User result = userService.updateUser(123L, updated);

        assertEquals("Updated", result.getName());
        assertEquals(123L, updated.getId());
    }

    @Test
    void testDeleteUser() {
        doNothing().when(userRepository).deleteById(123L);

        userService.deleteUser(123L);

        verify(userRepository, times(1)).deleteById(123L);
    }

    @Test
    void testSignup_SuccessDoctorRole() {
        User doctor = new User();
        doctor.setEmail("doc@example.com");
        doctor.setRole("DOCTOR");

        when(userRepository.findByEmail("doc@example.com")).thenReturn(Optional.empty());
        when(userRepository.save(doctor)).thenReturn(doctor);

        User result = userService.signup(doctor);

        assertEquals("doc@example.com", result.getEmail());
    }

    @Test
    void testSignup_ExistingUser() {
        User user = new User();
        user.setEmail("existing@example.com");
        user.setRole("DOCTOR");

        when(userRepository.findByEmail("existing@example.com"))
                .thenReturn(Optional.of(user));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            userService.signup(user);
        });

        assertEquals("User already exists with this email.", ex.getMessage());
    }

    @Test
    void testSignup_NonDoctorFails() {
        User admin = new User();
        admin.setEmail("admin@example.com");
        admin.setRole("ADMIN");

        when(userRepository.findByEmail("admin@example.com")).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            userService.signup(admin);
        });

        assertEquals("Only users with DOCTOR role can sign up directly.", ex.getMessage());
    }

    @Test
    void testLogin_Success() {
        User user = new User();
        user.setEmail("user@example.com");
        user.setPassword("pass");

        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(user));

        User result = userService.login("user@example.com", "pass");

        assertEquals("user@example.com", result.getEmail());
    }

    @Test
    void testLogin_WrongPassword() {
        User user = new User();
        user.setEmail("user@example.com");
        user.setPassword("correctpass");

        when(userRepository.findByEmail("user@example.com")).thenReturn(Optional.of(user));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            userService.login("user@example.com", "wrongpass");
        });

        assertEquals("Invalid email or password", ex.getMessage());
    }

    @Test
    void testLogin_UserNotFound() {
        when(userRepository.findByEmail("notfound@example.com")).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> {
            userService.login("notfound@example.com", "pass");
        });

        assertEquals("Invalid email or password", ex.getMessage());
    }
}
